from __future__ import annotations

from typing import Any

from src.evidence_collector import fetch_json
from src.config import API_BASE_URL, INGESTION_BASE_URL, PROMETHEUS_BASE_URL
from src.prometheus_client import query_prometheus


def _passed(ok: bool) -> str:
    return "passed" if ok else "failed"


def verify_platform_health() -> dict[str, Any]:
    api_health = fetch_json("backend_api_health", f"{API_BASE_URL.rstrip('/')}/health")
    ingestion_health = fetch_json(
        "ingestion_api_health",
        f"{INGESTION_BASE_URL.rstrip('/')}/health",
    )

    prometheus_up = query_prometheus("up")
    aiops_metric = query_prometheus("venueops_aiops_runbook_approvals_total")

    checks = [
        {
            "name": "backend_api_health",
            "status": _passed(
                bool(api_health.get("ok"))
                and api_health.get("body", {}).get("status") == "ok"
            ),
            "details": api_health,
        },
        {
            "name": "ingestion_api_health",
            "status": _passed(
                bool(ingestion_health.get("ok"))
                and ingestion_health.get("body", {}).get("status") == "ok"
            ),
            "details": ingestion_health,
        },
        {
            "name": "prometheus_targets_query",
            "status": _passed(
                bool(prometheus_up.get("ok"))
                and len(prometheus_up.get("result", [])) > 0
            ),
            "details": prometheus_up,
        },
        {
            "name": "aiops_approval_metric_query",
            "status": _passed(
                bool(aiops_metric.get("ok"))
            ),
            "details": aiops_metric,
        },
    ]

    failed = [check for check in checks if check["status"] != "passed"]

    return {
        "status": "passed" if not failed else "failed",
        "summary": (
            "Platform health verification passed."
            if not failed
            else "Platform health verification failed for one or more checks."
        ),
        "checks": checks,
    }
