from __future__ import annotations

from typing import Any, Literal

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from prometheus_client import CONTENT_TYPE_LATEST, Counter, generate_latest
from pydantic import BaseModel
from starlette.responses import Response

from src.audit_store import append_audit, read_audit
from src.config import APP_ENV, OLLAMA_BASE_URL, OLLAMA_MODEL
from src.evidence_collector import collect_current_evidence, simulated_incident
from src.incident_analyzer import analyze_incident
from src.runbook_registry import get_runbook, list_runbooks
from src.verifier import verify_platform_health


app = FastAPI(
    title="VenueOps AI Ops Service",
    version="0.1.0",
    description="Incident analysis, runbook recommendation, approval, verification, and audit service.",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

ANALYSES_TOTAL = Counter(
    "venueops_aiops_analyses_total",
    "Total number of AI Ops incident analyses.",
)

APPROVALS_TOTAL = Counter(
    "venueops_aiops_runbook_approvals_total",
    "Total number of AI Ops runbook approvals.",
)

VERIFICATIONS_TOTAL = Counter(
    "venueops_aiops_verifications_total",
    "Total number of AI Ops post-runbook verifications.",
)


class SimulateRequest(BaseModel):
    kind: Literal["api_5xx_spike", "ingestion_slowdown", "queue_backlog", "generic"] = "generic"


class AnalyzeRequest(BaseModel):
    incident_kind: str | None = None
    evidence: dict[str, Any] | None = None


class ApproveRunbookRequest(BaseModel):
    runbook_id: str
    approved_by: str = "admin-demo"
    execute: bool = False
    verify: bool = True


@app.get("/health")
def health() -> dict[str, Any]:
    return {
        "status": "ok",
        "service": "aiops",
        "environment": APP_ENV,
        "llm_provider": "ollama",
        "ollama_base_url": OLLAMA_BASE_URL,
        "ollama_model": OLLAMA_MODEL,
    }


@app.get("/metrics")
def metrics() -> Response:
    return Response(generate_latest(), media_type=CONTENT_TYPE_LATEST)


@app.get("/runbooks")
def runbooks() -> dict[str, Any]:
    return {"items": list_runbooks()}


@app.post("/incidents/simulate")
def simulate_incident_endpoint(payload: SimulateRequest) -> dict[str, Any]:
    evidence = simulated_incident(payload.kind)

    record = append_audit(
        "aiops_incident_simulated",
        {
            "kind": payload.kind,
            "evidence": evidence,
        },
    )

    return {
        "incident": evidence,
        "audit": record,
    }


@app.post("/incidents/analyze")
def analyze(payload: AnalyzeRequest) -> dict[str, Any]:
    if payload.evidence:
        evidence = payload.evidence
    elif payload.incident_kind:
        evidence = simulated_incident(payload.incident_kind)
    else:
        evidence = collect_current_evidence()

    result = analyze_incident(evidence)
    ANALYSES_TOTAL.inc()

    record = append_audit(
        "aiops_incident_analyzed",
        {
            "evidence_source": evidence.get("source"),
            "incident_kind": evidence.get("kind"),
            "recommended_runbook": result.get("recommended_runbook"),
            "risk_level": result.get("risk_level"),
            "approval_required": result.get("approval_required"),
            "llm_status": result.get("llm_status"),
            "llm_called": result.get("llm_status", {}).get("called"),
            "llm_accepted": result.get("llm_status", {}).get("accepted"),
            "fallback_used": result.get("llm_status", {}).get("fallback_used"),
        },
    )

    return {
        "analysis": result,
        "audit": record,
    }


@app.post("/runbooks/approve")
def approve_runbook(payload: ApproveRunbookRequest) -> dict[str, Any]:
    runbook = get_runbook(payload.runbook_id)

    if not runbook:
        raise HTTPException(status_code=404, detail="Runbook not found")

    APPROVALS_TOTAL.inc()

    execution_result = {
        "status": "simulated_success",
        "message": "Runbook approval was recorded. No real production command was executed.",
    }

    if payload.execute:
        execution_result["message"] = (
            "Execution flag was requested, but this demo service only simulates remediation."
        )

    verification = None
    if payload.verify:
        verification = verify_platform_health()
        VERIFICATIONS_TOTAL.inc()

    record = append_audit(
        "aiops_runbook_approved",
        {
            "runbook_id": payload.runbook_id,
            "approved_by": payload.approved_by,
            "execution_mode": "simulated",
            "execution_result": execution_result,
            "verification": verification,
        },
    )

    return {
        "runbook": runbook,
        "execution_mode": "simulated",
        "execution_result": execution_result,
        "verification": verification,
        "audit": record,
    }


@app.post("/runbooks/verify")
def verify_runbook_result() -> dict[str, Any]:
    verification = verify_platform_health()
    VERIFICATIONS_TOTAL.inc()

    record = append_audit(
        "aiops_runbook_verified",
        {
            "verification": verification,
        },
    )

    return {
        "verification": verification,
        "audit": record,
    }


@app.get("/audit")
def audit(limit: int = 50) -> dict[str, Any]:
    return read_audit(limit=limit)
